import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-about-main',
  templateUrl: './about-main.component.html',
  styleUrls: ['./about-main.component.css']
})
export class AboutMainComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
